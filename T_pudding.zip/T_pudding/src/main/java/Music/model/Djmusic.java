package Music.model;

public class Djmusic{
private String djmusicl;
private String djtitle;
public Djmusic() {
	super();
}
public Djmusic(String djmusicl, String djtitle) {
	super();
	this.djmusicl = djmusicl;
	this.djtitle = djtitle;
}
public String getDjmusicl() {
	return djmusicl;
}
public void setDjmusicl(String djmusicl) {
	this.djmusicl = djmusicl;
}
public String getDjtitle() {
	return djtitle;
}
public void setDjtitle(String djtitle) {
	this.djtitle = djtitle;
}


}
